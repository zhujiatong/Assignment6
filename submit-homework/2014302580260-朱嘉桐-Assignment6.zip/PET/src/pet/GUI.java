package pet;


import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class GUI {
	public static void main (String args[]){
		new jiemian();
}	
}
class jiemian{		
    static int length=200;
    static String[]info=new String[length];
    static String[]info2=new String[length];
    static String[]info3=new String[length];
    static String[]info4=new String[length];
    static String[]info5=new String[length];
    static String[]info6=new String[length];
    static String[]info7=new String[length];
    static String[]info8=new String[length];
    static String[]info9=new String[length];
    static String[]info10=new String[length];
    static String[]info11=new String[length];
    static String[]info12=new String[length];
    static int i1=0;
    static int i2=0;
    static int i3=0;
    static int i4=0;
    static int i5=0;
    static int i6=0;
    static int i7=0;
    static int i8=0;
    static int i9=0;
    static int i10=0;
    static int i11=0;
    static int i12=0;
    static int i13=0;
    static int i14=0;
	private JLabel label1;
	private JLabel label2;
	private JLabel label3;
	private JLabel label4;
	private JLabel label5;
	private JLabel label6;
	private JLabel label7;
	private JLabel label8;
	private JLabel label9;
	private JLabel label10;
	private JLabel label11;
	private JLabel label12;
	private JLabel label13;
	private JLabel label14;
	private JLabel label15;
	private JLabel label16;
	private JLabel label17;
	private JFrame f;
	private JFrame f2;
	private JFrame f3;
	private JFrame f4;
	private JFrame f5;
	private JFrame f6;
	private JFrame f7;
	private JFrame f8;
	private JFrame f9;
	private JFrame f10;
	private JFrame f11;
	private JFrame f12;
	private JFrame f13;
	private JFrame f14;
	private JFrame f15;
	private JFrame f16;
	private JButton bt1;
	private JButton bt2;
	private JButton bt3;
	private JButton bt4;
	private JButton bt5;
	private JButton bt6;
	private JButton bt7;
	private JButton bt8;
	private JButton bt9;
	private JButton bt10;
	private JButton bt11;
	private JButton bt12;
	private JButton bt13;
	private JButton bt14;
	private JButton bt15;
	private JButton bt16;
	private JButton bt17;
	private JButton bt18;
	private JButton bt19;
	private JButton bt20;
	private JButton bt21;
	private JTextField jtf1;
	private JTextField jtf2;
	private JTextField jtf3;
	private JTextField jtf4;
	private JTextArea jta1;
	private JTextArea jta2;
	private JTextArea jta3;
	private JTextArea jta4;
	private JTextArea jta5;
	private JTextArea jta6;
	private JTextArea jta7;
	private JTextArea jta8;
	private JTextArea jta9;
	private JTextArea jta10;
	private JTextArea jta11;
	private JTextArea jta12;
	private String a;
	private String b;	
	private String c;
	private String d;
	private String m;
	private String n;
	private String account;
	private String password;
	private static String AccountInfo;
	private static String PasswordInfo;
    private int money=0;
	public static String Information() throws SQLException{
		String Result = "宠物信息:";
		Connection conn=null;
		String sql = "select*from pet where id=1";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功连接数据库！");
			conn=DriverManager.getConnection(url);
		    Statement stmt=conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    while(rs.next()){
		    	info[i1]=rs.getString("name")+"\n"+rs.getString("eat")+"\n"+rs.getString("live")+"\n"+rs.getString("drink")+"\n"+rs.getString("hobby");
		        i1++;
		    }
		    for(int n=0;n<i1;n++)
		 	{
		 	 Result=Result+"\n"+info[n];
		 	} 
		}
		catch (SQLException e) 
		{
		System.out.println("数据库连接失败！");
	    e.printStackTrace();
	    } 
		catch (Exception e) 
		{
	    e.printStackTrace();
	    } 
		finally {
	    conn.close();
		}
		return Result;
	}
	public static String Information2() throws SQLException{
		String Result2 = "宠物信息:";
		Connection conn=null;
		String sql = "select*from pet where id=2";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功连接数据库！");
			conn=DriverManager.getConnection(url);
		    Statement stmt=conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    while(rs.next()){
		    	info2[i2]=rs.getString("name")+"\n"+rs.getString("eat")+"\n"+rs.getString("live")+"\n"+rs.getString("drink")+"\n"+rs.getString("hobby");
		        i2++;
		    }
		    for(int n=0;n<i2;n++)
		 	{
		 	 Result2=Result2+"\n"+info2[n];
		 	} 
		}
		catch (SQLException e) 
		{
		System.out.println("数据库连接失败！");
	    e.printStackTrace();
	    } 
		catch (Exception e) 
		{
	    e.printStackTrace();
	    } 
		finally {
	    conn.close();
		}
		return Result2;
	}
	public static String Information3() throws SQLException{
		String Result3 = "宠物信息:";
		Connection conn=null;
		String sql = "select*from pet where id=3";
		String url="jdbc:mysql://localhost:3306/petinfo?"
	    +"user=root&password=zhujiatong&useUnicode=true&characterEncoding=UTF8";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功连接数据库！");
			conn=DriverManager.getConnection(url);
		    Statement stmt=conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    while(rs.next()){
		    	info3[i3]=rs.getString("name")+"\n"+rs.getString("eat")+"\n"+rs.getString("live")+"\n"+rs.getString("drink")+"\n"+rs.getString("hobby");
		        i3++;
		    }
		    for(int n=0;n<i3;n++)
		 	{
		 	 Result3=Result3+"\n"+info3[n];
		 	} 
		}
		catch (SQLException e) 
		{
		System.out.println("数据库连接失败！");
	    e.printStackTrace();
	    } 
		catch (Exception e) 
		{
	    e.printStackTrace();
	    } 
		finally {
	    conn.close();
		}
		return Result3;
	}
	public static String Information4() throws SQLException{
		String Result4 = "宠物信息:";
		Connection conn=null;
		String sql = "select*from pet where id=4";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功连接数据库！");
			conn=DriverManager.getConnection(url);
		    Statement stmt=conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    while(rs.next()){
		    	info4[i4]=rs.getString("name")+"\n"+rs.getString("eat")+"\n"+rs.getString("live")+"\n"+rs.getString("drink")+"\n"+rs.getString("hobby");
		        i4++;
		    }
		    for(int n=0;n<i4;n++)
		 	{
		 	 Result4=Result4+"\n"+info4[n];
		 	} 
		}
		catch (SQLException e) 
		{
		System.out.println("数据库连接失败！");
	    e.printStackTrace();
	    } 
		catch (Exception e) 
		{
	    e.printStackTrace();
	    } 
		finally {
	    conn.close();
		}
		return Result4;
	}
	public static String Information5() throws SQLException{
		String Result5 = "宠物信息:";
		Connection conn=null;
		String sql = "select*from pet where id=5";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功连接数据库！");
			conn=DriverManager.getConnection(url);
		    Statement stmt=conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    while(rs.next()){
		    	info5[i5]=rs.getString("name")+"\n"+rs.getString("eat")+"\n"+rs.getString("live")+"\n"+rs.getString("drink")+"\n"+rs.getString("hobby");
		        i5++;
		    }
		    for(int n=0;n<i5;n++)
		 	{
		 	 Result5=Result5+"\n"+info5[n];
		 	} 
		}
		catch (SQLException e) 
		{
		System.out.println("数据库连接失败！");
	    e.printStackTrace();
	    } 
		catch (Exception e) 
		{
	    e.printStackTrace();
	    } 
		finally {
	    conn.close();
		}
		return Result5;
	}
	public static String Information6() throws SQLException{
		String Result6 = "宠物信息:";
		Connection conn=null;
		String sql = "select*from pet where id=6";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功连接数据库！");
			conn=DriverManager.getConnection(url);
		    Statement stmt=conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    while(rs.next()){
		    	info6[i6]=rs.getString("name")+"\n"+rs.getString("eat")+"\n"+rs.getString("live")+"\n"+rs.getString("drink")+"\n"+rs.getString("hobby");
		        i6++;
		    }
		    for(int n=0;n<i1;n++)
		 	{
		 	 Result6=Result6+"\n"+info6[n];
		 	} 
		}
		catch (SQLException e) 
		{
		System.out.println("数据库连接失败！");
	    e.printStackTrace();
	    } 
		catch (Exception e) 
		{
	    e.printStackTrace();
	    } 
		finally {
	    conn.close();
		}
		return Result6;
	}
	public static String Information7() throws SQLException{
		String Result7 = "宠物信息:";
		Connection conn=null;
		String sql = "select*from pet where id=7";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功连接数据库！");
			conn=DriverManager.getConnection(url);
		    Statement stmt=conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    while(rs.next()){
		    	info7[i7]=rs.getString("name")+"\n"+rs.getString("eat")+"\n"+rs.getString("live")+"\n"+rs.getString("drink")+"\n"+rs.getString("hobby");
		        i7++;
		    }
		    for(int n=0;n<i7;n++)
		 	{
		    Result7=Result7+"\n"+info7[n];
		 	} 
		}
		catch (SQLException e) 
		{
		System.out.println("数据库连接失败！");
	    e.printStackTrace();
	    } 
		catch (Exception e) 
		{
	    e.printStackTrace();
	    } 
		finally {
	    conn.close();
		}
		return Result7;
	}
	public static String Information8() throws SQLException{
		String Result8 = "宠物信息:";
		Connection conn=null;
		String sql = "select*from pet where id=8";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功连接数据库！");
			conn=DriverManager.getConnection(url);
		    Statement stmt=conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    while(rs.next()){
		    	info8[i8]=rs.getString("name")+"\n"+rs.getString("eat")+"\n"+rs.getString("live")+"\n"+rs.getString("drink")+"\n"+rs.getString("hobby");
		        i8++;
		    }
		    for(int n=0;n<i8;n++)
		 	{
		 	 Result8=Result8+"\n"+info8[n];
		 	} 
		}
		catch (SQLException e) 
		{
		System.out.println("数据库连接失败！");
	    e.printStackTrace();
	    } 
		catch (Exception e) 
		{
	    e.printStackTrace();
	    } 
		finally {
	    conn.close();
		}
		return Result8;
	}
	public static String Information9() throws SQLException{
		String Result9 = "宠物信息:";
		Connection conn=null;
		String sql = "select*from pet where id=9";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功连接数据库！");
			conn=DriverManager.getConnection(url);
		    Statement stmt=conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    while(rs.next()){
		    	info9[i9]=rs.getString("name")+"\n"+rs.getString("eat")+"\n"+rs.getString("live")+"\n"+rs.getString("drink")+"\n"+rs.getString("hobby");
		        i9++;
		    }
		    for(int n=0;n<i9;n++)
		 	{
		 	 Result9=Result9+"\n"+info9[n];
		 	} 
		}
		catch (SQLException e) 
		{
		System.out.println("数据库连接失败！");
	    e.printStackTrace();
	    } 
		catch (Exception e) 
		{
	    e.printStackTrace();
	    } 
		finally {
	    conn.close();
		}
		return Result9;
	}
	public static String Information10() throws SQLException{
		String Result10 = "宠物信息:";
		Connection conn=null;
		String sql = "select*from pet where id=10";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功连接数据库！");
			conn=DriverManager.getConnection(url);
		    Statement stmt=conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    while(rs.next()){
		    	info[i10]=rs.getString("name")+"\n"+rs.getString("eat")+"\n"+rs.getString("live")+"\n"+rs.getString("drink")+"\n"+rs.getString("hobby");
		        i10++;
		    }
		    for(int n=0;n<i10;n++)
		 	{
		 	 Result10=Result10+"\n"+info10[n];
		 	} 
		}
		catch (SQLException e) 
		{
		System.out.println("数据库连接失败！");
	    e.printStackTrace();
	    } 
		catch (Exception e) 
		{
	    e.printStackTrace();
	    } 
		finally {
	    conn.close();
		}
		return Result10;
	}
	public static String Information11() throws SQLException{
		String Result11 = "宠物信息:";
		Connection conn=null;
		String sql = "select*from pet where id=11";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功连接数据库！");
			conn=DriverManager.getConnection(url);
		    Statement stmt=conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    while(rs.next()){
		    	info11[i11]=rs.getString("name")+"\n"+rs.getString("eat")+"\n"+rs.getString("live")+"\n"+rs.getString("drink")+"\n"+rs.getString("hobby");
		        i11++;
		    }
		    for(int n=0;n<i11;n++)
		 	{
		 	 Result11=Result11+"\n"+info11[n];
		 	} 
		}
		catch (SQLException e) 
		{
		System.out.println("数据库连接失败！");
	    e.printStackTrace();
	    } 
		catch (Exception e) 
		{
	    e.printStackTrace();
	    } 
		finally {
	    conn.close();
		}
		return Result11;
	}
	public static String Information12() throws SQLException{
		String Result12 = "宠物信息:";
		Connection conn=null;
		String sql = "select*from pet where id=12";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("成功连接数据库！");
			conn=DriverManager.getConnection(url);
		    Statement stmt=conn.createStatement();
		    ResultSet rs = stmt.executeQuery(sql);
		    while(rs.next()){
		    	info[i12]=rs.getString("name")+"\n"+rs.getString("eat")+"\n"+rs.getString("live")+"\n"+rs.getString("drink")+"\n"+rs.getString("hobby");
		        i12++;
		    }
		    for(int n=0;n<i12;n++)
		 	{
		 	 Result12=Result12+"\n"+info[n];
		 	} 
		}
		catch (SQLException e) 
		{
		System.out.println("数据库连接失败！");
	    e.printStackTrace();
	    } 
		catch (Exception e) 
		{
	    e.printStackTrace();
	    } 
		finally {
	    conn.close();
		}
		return Result12;
	}
public static void AccountInfo()throws SQLException{
	Connection conn=null;
	String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
    try{
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("成功连接数据库！");
		conn=DriverManager.getConnection(url);
	    Statement stmt=conn.createStatement();
	    stmt.execute("insert into accountinfo2 (Account,Password) value (account, password)");
    }
    catch (SQLException e) 
	{
	System.out.println("数据库连接失败！");
    e.printStackTrace();
    } 
	catch (Exception e) 
	{
    e.printStackTrace();
    } 
	finally {
    conn.close();
	}
    }
public static void ReadInfo() throws SQLException{
	Connection conn=null;
	String sql = "select*from accountinfo2";
	String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	try{
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("成功连接数据库！");
		conn=DriverManager.getConnection(url);
	    Statement stmt=conn.createStatement();
	    ResultSet rs = stmt.executeQuery(sql);
	    while(rs.next()){
	    AccountInfo=rs.getString("Account");
	    PasswordInfo=rs.getString("Password");
	    }
	}
	catch (SQLException e) 
	{
	System.out.println("数据库连接失败！");
    e.printStackTrace();
    } 
	catch (Exception e) 
	{
    e.printStackTrace();
    } 
	finally {
    conn.close();
	}
}
public jiemian(){
    label1=new JLabel("账号:");
	label2=new JLabel("密码:");
	f = new JFrame();
	bt1=new JButton("登录:");
	bt2=new JButton("注册:");
	jtf1=new JTextField();
	jtf2=new JTextField();
	f.setVisible(true);
	f.setLayout(null);
	f.setResizable(false);
	f.setLocation(500,150);
	f.setSize(500,360);
	bt1.setBounds(340, 220, 100, 30);
	f.add(bt1);
	bt2.setBounds(40,220,100,30);
	f.add(bt2);
	jtf1.setBounds(70,20,350,30);
	f.add(jtf1);
	jtf2.setBounds(70,60,350,30);
	f.add(jtf2);
	label1.setSize(30,20);
	label1.setLocation(30,20);
	f.add(label1);
	label2.setSize(30,20);
	label2.setLocation(30,60);
	f.add(label2);	
	bt2.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"注册成功！");
			f.setVisible(false);
			f2.setVisible(true);	
			account=jtf1.getText();
			password=jtf2.getText();
			try {
				AccountInfo();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	});
	bt1.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			try {
				ReadInfo();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			m=jtf1.getText();
			n=jtf2.getText();
			Pattern pattern=Pattern.compile(AccountInfo);
	        Matcher m3=pattern.matcher(m);
	        Pattern pattern2=Pattern.compile(PasswordInfo);
	        Matcher m4=pattern2.matcher(n);
	        if(m3.find()&&m4.find()){
	        	JOptionPane.showMessageDialog(null,"登陆成功！");
	        	f2.setVisible(false);
	        	f3.setVisible(true);
	        }
	        else{
	        	JOptionPane.showMessageDialog(null,"登录失败！");
	        }
		}
		
	});
	label3=new JLabel("账号:");
	label4=new JLabel("密码:");
	f2=new JFrame();
	bt3=new JButton("登录:");
	bt4=new JButton("注册:");
	jtf3=new JTextField();
	jtf4=new JTextField();
	f2.setLayout(null);
	f2.setResizable(false);
	f2.setLocation(500,150);
	f2.setSize(500,360);
	bt3.setBounds(340, 220, 100, 30);
	f2.add(bt3);
	bt4.setBounds(40,220,100,30);
	f2.add(bt4);
	jtf3.setBounds(70,20,350,30);
	f2.add(jtf3);
	jtf4.setBounds(70,60,350,30);
	f2.add(jtf4);
	label3.setSize(30,20);
	label3.setLocation(30,20);
	f2.add(label3);
	label4.setSize(30,20);
	label4.setLocation(30,60);
	f2.add(label4);

	bt3.addActionListener(new ActionListener(){
		@Override
		public void actionPerformed(ActionEvent e) {
	      c=jtf3.getText();
	      d=jtf4.getText();
			// TODO Auto-generated method stub
	      try {
			ReadInfo();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        Pattern pattern=Pattern.compile(AccountInfo);
        Matcher m=pattern.matcher(c);
        Pattern pattern2=Pattern.compile(PasswordInfo);
        Matcher m2=pattern2.matcher(d);
        if(m.find()&&m2.find()){
        	JOptionPane.showMessageDialog(null,"登陆成功！");
        	f2.setVisible(false);
        	f3.setVisible(true);
        }
        else{
        	JOptionPane.showMessageDialog(null,"登录失败，请检查用户名与密码！");
        }
		}
		
	});
	f3=new JFrame();
	f3.setLayout(null);
	f3.setLocation(500,150);
	f3.setSize(1000,1000);
	f3.setResizable(false);
	bt5=new JButton("dog");
	bt6=new JButton("cat");
	bt7=new JButton("turtle");
	bt8=new JButton("parrot");
	bt9=new JButton("hamster");
	bt10=new JButton("squirrel");
	bt11=new JButton("rabbit");
	bt12=new JButton("snake");
	bt13=new JButton("lizard");
	bt14=new JButton("fish");
	bt15=new JButton("myna");
	bt16=new JButton("canary");
	bt5.setBounds(340,220,100,30);
	f3.add(bt5);
	bt6.setBounds(450,220,100,30);
	f3.add(bt6);
	bt7.setBounds(560,220,100,30);
	f3.add(bt7);
	bt8.setBounds(340,420,100,30);
	f3.add(bt8);
	bt9.setBounds(450,420,100,30);
	f3.add(bt9);
	bt10.setBounds(560,420,100,30);
	f3.add(bt10);
	bt11.setBounds(340,620,100,30);
	f3.add(bt11);
	bt12.setBounds(450,620,100,30);
	f3.add(bt12);
	bt13.setBounds(560,620,100,30);
	f3.add(bt13);
	bt14.setBounds(340,820,100,30);
	f3.add(bt14);
	bt15.setBounds(450,820,100,30);
	f3.add(bt15);
	bt16.setBounds(560,820,100,30);
	f3.add(bt16);
	bt5.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f3.setVisible(false);
			f4.setVisible(true);
		}
		
	});
	bt6.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f3.setVisible(false);
			f5.setVisible(true);
		}
		
	});
	bt7.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f3.setVisible(false);
			f6.setVisible(true);
		}
		
	});
	bt8.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f3.setVisible(false);
			f7.setVisible(true);
		}
		
	});
	bt9.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f3.setVisible(false);
			f8.setVisible(true);
		}
		
	});
	bt10.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f3.setVisible(false);
			f9.setVisible(true);
		}
		
	});
	bt11.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f3.setVisible(false);
			f10.setVisible(true);
		}
		
	});
	bt12.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f3.setVisible(false);
			f11.setVisible(true);
		}
		
	});
	bt13.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f3.setVisible(false);
			f12.setVisible(true);
		}
		
	});
	bt14.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f3.setVisible(false);
			f13.setVisible(true);
		}
		
	});
	bt15.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f3.setVisible(false);
			f14.setVisible(true);
		}
		
	});
	bt16.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f3.setVisible(false);
			f15.setVisible(true);
		}
		
	});
	f4=new JFrame();
	f4.setLayout(null);
	f4.setResizable(false);
	f4.setLocation(500,150);
	f4.setSize(1000,1000);
	jta1=new JTextArea();
	try {
		jta1.setText(Information());
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	jta1.setSize(600,600);
	jta1.setLocation(200,200);
	jta1.setEditable(false);
	Font mf=new Font("Serif",0,20);
	jta1.setFont(mf);
	f4.add(jta1);
	bt17=new JButton("添加至购物车");
	bt17.setLocation(200,800);
	bt17.setSize(150,50);
	f4.add(bt17);
	bt18=new JButton("查看购物车");
	bt18.setLocation(700,800);
	bt18.setSize(150,50);
	f4.add(bt18);
	bt19=new JButton("返回");
	bt19.setLocation(375,800);
	bt19.setSize(150,50);
	f4.add(bt19);
	bt17.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"已成功添加至购物车！");
			f16.add(label5);
			money=money+10;
		}
		
	});
	bt18.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(true);
			f4.setVisible(false);
		}
		
	});
	bt19.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
        f4.setVisible(false);
        f3.setVisible(true);
		}
		});
	f5=new JFrame();
	f5.setLayout(null);
	f5.setResizable(false);
	f5.setLocation(500,150);
	f5.setSize(1000,1000);
	jta2=new JTextArea();
	try {
		jta2.setText(Information2());
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	jta2.setSize(600,600);
	jta2.setLocation(200,200);
	jta2.setEditable(false);
	jta2.setFont(mf);
	f5.add(jta2);
	bt17=new JButton("添加至购物车");
	bt17.setLocation(200,800);
	bt17.setSize(150,50);
	f5.add(bt17);
	bt18=new JButton("查看购物车");
	bt18.setLocation(700,800);
	bt18.setSize(150,50);
	f5.add(bt18);
	bt19=new JButton("返回");
	bt19.setLocation(375,800);
	bt19.setSize(150,50);
	f5.add(bt19);
	bt17.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"已成功添加至购物车！");
			f16.add(label6);
			money=money+20;
		}
		
	});
	bt18.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(true);
			f4.setVisible(false);
		}
		
	});
	bt19.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
        f5.setVisible(false);
        f3.setVisible(true);
		}
		});
	f6=new JFrame();
	f6.setLayout(null);
	f6.setResizable(false);
	f6.setLocation(500,150);
	f6.setSize(1000,1000);
	jta3=new JTextArea();
	try {
		jta3.setText(Information3());
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	jta3.setSize(600,600);
	jta3.setLocation(200,200);
	jta3.setEditable(false);
	jta3.setFont(mf);
	f6.add(jta3);
	bt17=new JButton("添加至购物车");
	bt17.setLocation(200,800);
	bt17.setSize(150,50);
	f6.add(bt17);
	bt18=new JButton("查看购物车");
	bt18.setLocation(700,800);
	bt18.setSize(150,50);
	f6.add(bt18);
	bt19=new JButton("返回");
	bt19.setLocation(375,800);
	bt19.setSize(150,50);
	f6.add(bt19);
	bt17.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"已成功添加至购物车！");
			f16.add(label7);
			money=money+30;
		}
		
	});
	bt18.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(true);
			f4.setVisible(false);
		}
		
	});
	bt19.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
        f6.setVisible(false);
        f3.setVisible(true);
		}
		});
	f7=new JFrame();
	f7.setLayout(null);
	f7.setResizable(false);
	f7.setLocation(500,150);
	f7.setSize(1000,1000);
	jta4=new JTextArea();
	try {
		jta4.setText(Information4());
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	jta4.setSize(600,600);
	jta4.setLocation(200,200);
	jta4.setEditable(false);
	jta4.setFont(mf);
	f7.add(jta4);
	bt17=new JButton("添加至购物车");
	bt17.setLocation(200,800);
	bt17.setSize(150,50);
	f7.add(bt17);
	bt18=new JButton("查看购物车");
	bt18.setLocation(700,800);
	bt18.setSize(150,50);
	f7.add(bt18);
	bt19=new JButton("返回");
	bt19.setLocation(375,800);
	bt19.setSize(150,50);
	f7.add(bt19);
	bt17.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"已成功添加至购物车！");
			f16.add(label8);
			money=money+40;
		}
		
	});
	bt18.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(true);
			f4.setVisible(false);
		}
		
	});
	bt19.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
        f7.setVisible(false);
        f3.setVisible(true);
		}
		});
	f8=new JFrame();
	f8.setLayout(null);
	f8.setResizable(false);
	f8.setLocation(500,150);
	f8.setSize(1000,1000);
	jta5=new JTextArea();
	try {
		jta5.setText(Information5());
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	jta5.setSize(600,600);
	jta5.setLocation(200,200);
	jta5.setEditable(false);
	jta5.setFont(mf);
	f8.add(jta5);
	bt17=new JButton("添加至购物车");
	bt17.setLocation(200,800);
	bt17.setSize(150,50);
	f8.add(bt17);
	bt18=new JButton("查看购物车");
	bt18.setLocation(700,800);
	bt18.setSize(150,50);
	f8.add(bt18);
	bt19=new JButton("返回");
	bt19.setLocation(375,800);
	bt19.setSize(150,50);
	f8.add(bt19);
	bt17.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"已成功添加至购物车！");
			f16.add(label9);
			money=money+50;
		}
		
	});
	bt18.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(true);
			f4.setVisible(false);
		}
		
	});
	bt19.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
        f8.setVisible(false);
        f3.setVisible(true);
		}
		});
	f9=new JFrame();
	f9.setLayout(null);
	f9.setResizable(false);
	f9.setLocation(500,150);
	f9.setSize(1000,1000);
	jta6=new JTextArea();
	try {
		jta6.setText(Information6());
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	jta6.setSize(600,600);
	jta6.setLocation(200,200);
	jta6.setEditable(false);
	jta6.setFont(mf);
	f9.add(jta6);
	bt17=new JButton("添加至购物车");
	bt17.setLocation(200,800);
	bt17.setSize(150,50);
	f9.add(bt17);
	bt18=new JButton("查看购物车");
	bt18.setLocation(700,800);
	bt18.setSize(150,50);
	f9.add(bt18);
	bt19=new JButton("返回");
	bt19.setLocation(375,800);
	bt19.setSize(150,50);
	f9.add(bt19);
	bt17.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"已成功添加至购物车！");
			f16.add(label10);
			money=money+60;
		}
		
	});
	bt18.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(true);
			f4.setVisible(false);
		}
		
	});
	bt19.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
        f9.setVisible(false);
        f3.setVisible(true);
		}
		});
	f10=new JFrame();
	f10.setLayout(null);
	f10.setResizable(false);
	f10.setLocation(500,150);
	f10.setSize(1000,1000);
	jta7=new JTextArea();
	try {
		jta7.setText(Information7());
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	jta7.setSize(600,600);
	jta7.setLocation(200,200);
	jta7.setEditable(false);
	jta7.setFont(mf);
	f10.add(jta7);
	bt17=new JButton("添加至购物车");
	bt17.setLocation(200,800);
	bt17.setSize(150,50);
	f10.add(bt17);
	bt18=new JButton("查看购物车");
	bt18.setLocation(700,800);
	bt18.setSize(150,50);
	f10.add(bt18);
	bt19=new JButton("返回");
	bt19.setLocation(375,800);
	bt19.setSize(150,50);
	f10.add(bt19);
	bt17.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"已成功添加至购物车！");
			f16.add(label11);
			money=money+70;
		}
		
	});
	bt18.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(true);
			f4.setVisible(false);
		}
		
	});
	bt19.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
        f10.setVisible(false);
        f3.setVisible(true);
		}
		});
	f11=new JFrame();
	f11.setLayout(null);
	f11.setResizable(false);
	f11.setLocation(500,150);
	f11.setSize(1000,1000);
	jta8=new JTextArea();
	try {
		jta8.setText(Information8());
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	jta8.setSize(600,600);
	jta8.setLocation(200,200);
	jta8.setEditable(false);
	jta8.setFont(mf);
	f11.add(jta8);
	bt17=new JButton("添加至购物车");
	bt17.setLocation(200,800);
	bt17.setSize(150,50);
	f11.add(bt17);
	bt18=new JButton("查看购物车");
	bt18.setLocation(700,800);
	bt18.setSize(150,50);
	f11.add(bt18);
	bt19=new JButton("返回");
	bt19.setLocation(375,800);
	bt19.setSize(150,50);
	f11.add(bt19);
	bt17.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"已成功添加至购物车！");
			f16.add(label12);
			money=money+80;
		}
		
	});
	bt18.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(true);
			f4.setVisible(false);
		}
		
	});
	bt19.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
        f11.setVisible(false);
        f3.setVisible(true);
		}
		});
	f12=new JFrame();
	f12.setLayout(null);
	f12.setResizable(false);
	f12.setLocation(500,150);
	f12.setSize(1000,1000);
	jta9=new JTextArea();
	try {
		jta9.setText(Information9());
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	jta9.setSize(600,600);
	jta9.setLocation(200,200);
	jta9.setEditable(false);
	jta9.setFont(mf);
	f12.add(jta9);
	bt17=new JButton("添加至购物车");
	bt17.setLocation(200,800);
	bt17.setSize(150,50);
	f12.add(bt17);
	bt18=new JButton("查看购物车");
	bt18.setLocation(700,800);
	bt18.setSize(150,50);
	f12.add(bt18);
	bt19=new JButton("返回");
	bt19.setLocation(375,800);
	bt19.setSize(150,50);
	f12.add(bt19);
	bt17.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"已成功添加至购物车！");
			f16.add(label13);
			money=money+90;
		}
		
	});
	bt18.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(true);
			f4.setVisible(false);
		}
		
	});
	bt19.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
        f12.setVisible(false);
        f3.setVisible(true);
		}
		});
	f13=new JFrame();
	f13.setLayout(null);
	f13.setResizable(false);
	f13.setLocation(500,150);
	f13.setSize(1000,1000);
	jta10=new JTextArea();
	try {
		jta10.setText(Information10());
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	jta10.setSize(600,600);
	jta10.setLocation(200,200);
	jta10.setEditable(false);
	jta10.setFont(mf);
	f13.add(jta10);
	bt17=new JButton("添加至购物车");
	bt17.setLocation(200,800);
	bt17.setSize(150,50);
	f13.add(bt17);
	bt18=new JButton("查看购物车");
	bt18.setLocation(700,800);
	bt18.setSize(150,50);
	f13.add(bt18);
	bt19=new JButton("返回");
	bt19.setLocation(375,800);
	bt19.setSize(150,50);
	f13.add(bt19);
	bt17.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"已成功添加至购物车！");
			f16.add(label14);
			money=money+100;
		}
		
	});
	bt18.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(true);
			f4.setVisible(false);
		}
		
	});
	bt19.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
        f13.setVisible(false);
        f3.setVisible(true);
		}
		});
	f14=new JFrame();
	f14.setLayout(null);
	f14.setResizable(false);
	f14.setLocation(500,150);
	f14.setSize(1000,1000);
	jta11=new JTextArea();
	try {
		jta11.setText(Information11());
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	jta11.setSize(600,600);
	jta11.setLocation(200,200);
	jta11.setEditable(false);
	jta11.setFont(mf);
	f14.add(jta11);
	bt17=new JButton("添加至购物车");
	bt17.setLocation(200,800);
	bt17.setSize(150,50);
	f14.add(bt17);
	bt18=new JButton("查看购物车");
	bt18.setLocation(700,800);
	bt18.setSize(150,50);
	f14.add(bt18);
	bt19=new JButton("返回");
	bt19.setLocation(375,800);
	bt19.setSize(150,50);
	f14.add(bt19);
	bt17.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"已成功添加至购物车！");
			f16.add(label15);
			money=money+110;
		}
		
	});
	bt18.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(true);
			f4.setVisible(false);
		}
		
	});
	bt19.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
        f14.setVisible(false);
        f3.setVisible(true);
		}
		});
	f15=new JFrame();
	f15.setLayout(null);
	f15.setResizable(false);
	f15.setLocation(500,150);
	f15.setSize(1000,1000);
	jta12=new JTextArea();
	try {
		jta12.setText(Information12());
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	jta12.setSize(600,600);
	jta12.setLocation(200,200);
	jta12.setEditable(false);
	jta12.setFont(mf);
	f15.add(jta12);
	bt17=new JButton("添加至购物车");
	bt17.setLocation(200,800);
	bt17.setSize(150,50);
	f15.add(bt17);
	bt18=new JButton("查看购物车");
	bt18.setLocation(700,800);
	bt18.setSize(150,50);
	f15.add(bt18);
	bt19=new JButton("返回");
	bt19.setLocation(375,800);
	bt19.setSize(150,50);
	f15.add(bt19);
	bt17.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null,"已成功添加至购物车！");
			f16.add(label16);
			money=money+120;
		}
		
	});
	bt18.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(true);
			f4.setVisible(false);
		}
		
	});
	bt19.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
        f15.setVisible(false);
        f3.setVisible(true);
		}
		});
	f16=new JFrame();
	f16.setVisible(false);
	f16.setLayout(null);
	f16.setResizable(false);
	f16.setLocation(500,150);
	f16.setSize(1000,1000);
	Font mf2=new Font("Serif",0,20);
	label5=new JLabel("dog,10yuan");
	label6=new JLabel("cat,20yuan");
	label7=new JLabel("turtle,30yuan");
	label8=new JLabel("parrot,40yuan");
	label9=new JLabel("hamster,50yuan");
	label10=new JLabel("squirrel,60yuan");
	label11=new JLabel("rabbit,70yuan");
	label12=new JLabel("snake,80yuan");
	label13=new JLabel("lizard,90yuan");
	label14=new JLabel("fish,100yuan");
	label15=new JLabel("myna,110yuan");
	label16=new JLabel("canary,120yuan");
	label17=new JLabel("已选择宠物");
	label5.setLocation(200,200);
	label5.setSize(200,30);
	label5.setFont(mf2);
	label6.setLocation(200,250);
	label6.setSize(200,30);
	label6.setFont(mf2);
	label7.setLocation(200,300);
	label7.setSize(200,30);
	label7.setFont(mf2);
	label8.setLocation(200,350);
	label8.setSize(200,30);
	label8.setFont(mf2);
	label9.setLocation(200,400);
	label9.setSize(200,30);
	label9.setFont(mf2);
	label10.setLocation(200,450);
	label10.setSize(200,30);
	label10.setFont(mf2);
	label11.setLocation(200,500);
	label11.setSize(200,30);
	label11.setFont(mf2);
	label12.setLocation(200,550);
	label12.setSize(200,30);
	label12.setFont(mf2);
	label13.setLocation(200,600);
	label13.setSize(200,30);
	label13.setFont(mf2);
	label14.setLocation(200,650);
	label14.setSize(200,30);
	label14.setFont(mf2);
	label15.setLocation(200,700);
	label15.setSize(200,30);
	label15.setFont(mf2);
	label16.setLocation(200,750);
	label16.setSize(200,30);
	label16.setFont(mf2);
	label17.setLocation(200,100);
	label17.setSize(200,30);
	label17.setFont(mf2);
	f16.add(label17);
	bt20=new JButton("结账");
	bt20.setLocation(600,800);
	bt20.setSize(100,30);
	f16.add(bt20);
	bt21=new JButton("返回");
	bt21.setLocation(200,800);
	bt21.setSize(100,30);
	f16.add(bt21);
	bt20.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			JOptionPane.showMessageDialog(null, "已付款"+money+"yuan");
		}
		
	});
	bt21.addActionListener(new ActionListener(){

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			f16.setVisible(false);
			f3.setVisible(true);
		}
		
	});
}
}