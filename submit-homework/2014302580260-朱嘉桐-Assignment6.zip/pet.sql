

use petinfo;
INSERT INTO `pet` (`id`,`name`,`eat`,`drink`,`live`,`hobby`)VALUES(1,'dog','bone','water','ground','play');
INSERT INTO `pet` (`id`,`name`,`eat`,`drink`,`live`,`hobby`)VALUES(2,'cat','fish','milk','roof','hug');
INSERT INTO `pet` (`id`,`name`,`eat`,`drink`,`live`,`hobby`)VALUES(3,'turtle','fish,shrimp','sea water','sea water','bask');
INSERT INTO `pet` (`id`,`name`,`eat`,`drink`,`live`,`hobby`)VALUES(4,'parrot','nuts,seeds','water','tree','fly');
INSERT INTO `pet` (`id`,`name`,`eat`,`drink`,`live`,`hobby`)VALUES(5,'hamster','Sunflower seed','water','corner','eat');
INSERT INTO `pet` (`id`,`name`,`eat`,`drink`,`live`,`hobby`)VALUES(6,'squirrel','pine cone','water','tree hole,underground','play');
INSERT INTO `pet` (`id`,`name`,`eat`,`drink`,`live`,`hobby`)VALUES(7,'rabbit','carrot','water','grassland,underground','eat');
INSERT INTO `pet` (`id`,`name`,`eat`,`drink`,`live`,`hobby`)VALUES(8,'snake','mouse','water','hole','bask');
INSERT INTO `pet` (`id`,`name`,`eat`,`drink`,`live`,`hobby`)VALUES(9,'lizard','bug','water','tree','bask');
INSERT INTO `pet` (`id`,`name`,`eat`,`drink`,`live`,`hobby`)VALUES(10,'fish','aquatic plant','water','water','swim');
INSERT INTO `pet` (`id`,`name`,`eat`,`drink`,`live`,`hobby`)VALUES(11,'myna','earthworm','water','tree','fly');
INSERT INTO `pet` (`id`,`name`,`eat`,`drink`,`live`,`hobby`)VALUES(12,'canary','millet','water','tree','sing');
